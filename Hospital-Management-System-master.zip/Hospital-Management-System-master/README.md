# Hospital-Management-System
Hospital Management System

To Start Website, run [run.bat](https://github.com/RyuzakiH/Hospital-Management-System/blob/master/Hospital-Management-System/run.bat)
